# Ep-2: Cadeias

**EP-2 acha cadeias em linguangens dada uma gramatica**
# Arthur Pires da Fonceca(Nusp: 10773096)  e Breno Loscher Rocha(Nusp: 9784439) 
## Testes
**Casos de uso em: Cadeia_test, para rodar use o comando "mix test"**


